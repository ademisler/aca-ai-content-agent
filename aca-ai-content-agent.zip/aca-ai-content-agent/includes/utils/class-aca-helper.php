<?php
/**
 * The helper utility.
 *
 * @link       https://yourwebsite.com
 * @since      1.2.0
 *
 * @package    ACA_AI_Content_Agent
 * @subpackage ACA_AI_Content_Agent/includes/utils
 */

/**
 * The helper utility.
 *
 * This class defines all code necessary for helper functions.
 *
 * @since      1.2.0
 * @package    ACA_AI_Content_Agent
 * @subpackage ACA_AI_Content_Agent/includes/utils
 * @author     Your Name <email@example.com>
 */
class ACA_Helper {

	/**
	 * Check if ACA Pro is active.
	 *
	 * @since    1.2.0
	 * @return boolean
	 */
	public static function is_pro() {
		// Check if the license check function exists and run it
	    if ( function_exists( 'aca_ai_content_agent_maybe_check_license' ) ) {
	        aca_ai_content_agent_maybe_check_license();
	    }

	    $is_active    = false;
	    $active_flag  = get_option( 'aca_ai_content_agent_is_pro_active' ) === 'true';
	    $valid_until  = intval( get_option( 'aca_ai_content_agent_license_valid_until', 0 ) );
	    $status       = get_transient( 'aca_ai_content_agent_license_status' );

	    if ( $active_flag && $valid_until > time() && $status === 'valid' ) {
	        $is_active = true;
	    }

	    return apply_filters( 'aca_ai_content_agent_is_pro', $is_active );
	}

}
