=== ACA - AI Content Agent ===
Contributors: ademisler
Tags: ai, content, generator
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

ACA is an intelligent plugin that learns your content's tone and style to autonomously generate high-quality new posts.
