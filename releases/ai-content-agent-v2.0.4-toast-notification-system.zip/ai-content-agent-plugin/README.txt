=== AI Content Agent ===
Contributors: ademisler
Donate link: https://ademisler.com/en
Tags: ai, content, automation, gemini, seo, pro, license
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 2.0.3
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-powered WordPress plugin with Pro licensing for automated content creation, SEO optimization, and Google Search Console integration.

== Description ==

AI Content Agent (ACA) transforms your WordPress site into an intelligent content creation powerhouse using Google's Gemini AI technology.

**🚀 Latest v2.0.4 Features:**
* Comprehensive Pro license system with unified controls
* Fixed Gumroad API integration with proper product_id usage
* Resolved frontend-backend license status synchronization
* Enhanced error messages and automatic pro status updates
* Added comprehensive debug logging for troubleshooting
* Improved user experience with consistent Pro feature access

== Changelog ==

= 2.0.4 - 2025-01-30 =
* Major: Comprehensive Pro license system with unified controls
* Fixed: Gumroad API integration with proper product_id usage (post-Jan 2023)
* Resolved: Frontend-backend license status synchronization issues
* Enhanced: Error messages and automatic pro status updates
* Added: Comprehensive debug logging for API troubleshooting
* Improved: User experience with consistent Pro feature access

= 1.9.1 - 2024-12-19 =
* Enhanced Settings page reorganization with user-focused layout
* Added Pro badges to Automation Mode and Google Search Console
* Improved license activation → feature configuration workflow
* Enhanced Google Search Console Pro integration with upgrade prompts
* Optimized UX/UI with better visual hierarchy and accessibility
* Updated build system and asset deployment

= 1.9.0 - 2024-12-19 =

= 1.8.0 - 2025-01-29 =
* **MAJOR**: Dashboard statistics optimization - shows only active ideas count
* **MAJOR**: Author information updated to Adem Isler with website integration
* **ENHANCEMENT**: Comprehensive feature verification and optimization
* **ENHANCEMENT**: Documentation updates with proper authorship
* **ENHANCEMENT**: Version consistency across all files
* **FIX**: Quality assurance verification of all plugin features

= 1.6.8 - 2025-01-29 =
* **MAJOR**: Added comprehensive Gemini API retry logic with exponential backoff
* **MAJOR**: Implemented automatic model fallback (gemini-2.0-flash → gemini-1.5-pro)
* **ENHANCEMENT**: User-friendly error messages with emojis and clear guidance
* **ENHANCEMENT**: Increased timeout limits (120s) and token limits (4096) for better performance
* **ENHANCEMENT**: Enhanced error detection for overload, timeout, and API key issues
* **FIX**: Production-grade error handling for AI service disruptions
* **FIX**: Comprehensive error logging for system administrators

= 1.6.7 - 2025-01-29 =
* **MAJOR**: Deep cache analysis and fix for WordPress JavaScript file loading
* **MAJOR**: Implemented React ErrorBoundary for graceful error handling
* **FIX**: WordPress cache bypass with unique script handles using MD5 hash
* **FIX**: File selection logic updated to use modification time instead of alphabetical order
* **FIX**: Removed old problematic JavaScript files causing initialization errors

= 1.6.6 - 2025-01-29 =
* **MAJOR**: Fixed WordPress cache issues preventing JavaScript file updates
* **MAJOR**: Resolved Google API dependency warnings with placeholder files
* **FIX**: Corrected JavaScript file loading path from admin/js to admin/assets
* **FIX**: Implemented proper file versioning with timestamp for cache bypass
* **ENHANCEMENT**: Created vendor/autoload.php placeholder for dependency checks

= 1.6.5 - 2025-01-29 =
* **MAJOR**: Fixed temporal dead zone errors by disabling minification
* **MAJOR**: Enhanced Vite build configuration for proper function execution order
* **FIX**: Changed Rollup output format to IIFE for better variable isolation
* **FIX**: Removed source maps to reduce bundle size and improve loading
* **ENHANCEMENT**: Complete resolution of "Cannot access 'Te' before initialization" errors

= 1.6.4 - 2025-01-29 =
* **CRITICAL**: Fixed "Cannot access 'Te' before initialization" JavaScript error
* **FIX**: Resolved function hoisting issues in App.tsx with proper declaration order
* **FIX**: Added window.acaData existence checks to all API calls in Settings.tsx
* **ENHANCEMENT**: Enhanced Terser configuration to prevent variable hoisting
* **ENHANCEMENT**: Improved WordPress data availability checks throughout application

= 1.6.3 - 2025-01-29 =
* **MAJOR**: Comprehensive documentation update across all files
* **ENHANCEMENT**: Updated all version references to maintain consistency
* **ENHANCEMENT**: Improved setup guides for all integrations
* **ENHANCEMENT**: Enhanced build processes and deployment procedures
* **ENHANCEMENT**: Better file organization and release management

= 1.6.2 - 2025-01-28 =
* **CRITICAL**: Fixed JavaScript initialization error completely
* **FIX**: Switched from ESBuild to Terser minifier for safer variable scoping
* **FIX**: Updated build target from ES2015 to ES2020 for better compatibility
* **ENHANCEMENT**: Improved WordPress plugin asset management
* **ENHANCEMENT**: Enhanced build system with optimized settings

= 1.6.1 - 2025-01-28 =
* **FIX**: Fixed window object consistency issues
* **ENHANCEMENT**: Improved browser compatibility
* **FIX**: Resolved various initialization edge cases

= 1.6.0 - 2025-01-28 =
* **MAJOR**: Fixed build system and React initialization
* **ENHANCEMENT**: Improved overall plugin stability
* **FIX**: Resolved multiple compatibility issues

== Upgrade Notice ==

= 1.6.8 =
Major update with intelligent Gemini API retry logic and enhanced error handling. Automatic model fallback ensures content creation continues even when AI services are overloaded. Highly recommended update for production sites.

= 1.6.7 =
Critical update fixing WordPress cache issues and JavaScript initialization errors. Includes React ErrorBoundary for graceful error handling. Essential update for all users.

= 1.6.6 =
Important update resolving cache and dependency issues. Fixes JavaScript file loading and eliminates dependency warnings. Recommended for all users experiencing loading issues.

= 1.6.5 =
Critical update completely fixing temporal dead zone JavaScript errors. All users experiencing "Cannot access before initialization" errors should update immediately.

= 1.6.4 =
Critical JavaScript initialization error fix. Essential update for users experiencing plugin loading issues or console errors.

== Additional Info ==

**Minimum Requirements:**
* WordPress 5.0 or higher
* PHP 7.4 or higher
* Gemini AI API key (required for content generation)

**Recommended:**
* WordPress 6.8 or higher
* PHP 8.0 or higher
* Google Search Console account (optional)
* Modern web browser with JavaScript enabled

**Support:**
* Comprehensive documentation included
* GitHub repository for issues and feature requests
* Regular updates and improvements
* Community support through WordPress forums

**Privacy:**
* Plugin only sends content to Google's Gemini AI for generation
* No personal data is stored or transmitted without explicit user action
* Google Search Console data is only accessed with explicit user authorization

== Changelog ==

= 2.0.3 =
* Fixed: Dual-asset system implementation for proper WordPress integration
* Fixed: Cache invalidation issues with updated file timestamps
* Enhanced: View button icon contrast and accessibility improvements
* Improved: Build process following DEVELOPER_GUIDE.md exactly
* Updated: WordPress asset loading system with proper file selection

= 2.0.2 =
* Fixed: Build process and asset verification
* Improved: Asset deployment and file management
* Updated: Quality assurance for user-visible changes

= 2.0.1 =
* Enhanced: View button icon contrast in Published Posts and Drafts
* Improved: Stroke-based icon handling in CSS
* Fixed: Color contrast ratios for better accessibility
* Updated: Icon styling architecture for consistency

= 2.0.0 =
* Fixed: Idea Board overflow issues in 4-column layout
* Improved: Grid layout responsiveness and button placement
* Enhanced: CSS grid system with better breakpoints
* Updated: Visual consistency across UI components
* All API communications are secured with HTTPS