<?php
/**
 * WP-Cron functionality for automated tasks
 */

if (!defined('ABSPATH')) {
    exit;
}

// Ensure ACA_PLUGIN_PATH is defined
if (!defined('ACA_PLUGIN_PATH')) {
    define('ACA_PLUGIN_PATH', plugin_dir_path(dirname(__FILE__)));
}

class ACA_Cron {
    
    public function __construct() {
        $this->init();
    }
    
    public function init() {
        // Add custom cron schedules
        add_filter('cron_schedules', array($this, 'add_cron_intervals'));
        
        // Cron events are now hooked in main plugin file as static methods
    }
    
    /**
     * Add custom cron intervals
     */
    public function add_cron_intervals($schedules) {
        $schedules['aca_thirty_minutes'] = array(
            'interval' => 30 * 60, // 30 minutes in seconds
            'display' => __('Every 30 Minutes', 'ai-content-agent')
        );
        
        $schedules['aca_fifteen_minutes'] = array(
            'interval' => 15 * 60, // 15 minutes in seconds
            'display' => __('Every 15 Minutes', 'ai-content-agent')
        );
        
        return $schedules;
    }
    
    /**
     * Task that runs every 30 minutes
     * Handles full-automatic mode operations
     */
    public static function thirty_minute_task() {
        $settings = get_option('aca_settings', array());
        
        if (empty($settings['geminiApiKey'])) {
            return;
        }
        
        // Update last run time
        update_option('aca_last_cron_run', current_time('mysql') . ' (30min - Full-Auto)');
        
        // Auto-analyze style guide
        self::auto_analyze_style_guide();
        
        // Run content freshness analysis
        self::content_freshness_task();
        
        // Run full content cycle if in full-automatic mode
        if (isset($settings['mode']) && $settings['mode'] === 'full-automatic') {
            // Check if pro license is active for full-automatic mode
            if (is_aca_pro_active()) {
                self::run_full_automatic_cycle();
            } else {
                error_log('ACA: Full-automatic mode requires Pro license');
            }
        }
    }
    
    /**
     * Task that runs every 15 minutes
     * Handles semi-automatic mode operations
     */
    public static function fifteen_minute_task() {
        $settings = get_option('aca_settings', array());
        
        if (empty($settings['geminiApiKey'])) {
            return;
        }
        
        // Update last run time
        update_option('aca_last_cron_run', current_time('mysql') . ' (15min - Semi-Auto)');
        
        // Generate ideas in semi-automatic mode
        if (isset($settings['mode']) && $settings['mode'] === 'semi-automatic') {
            // Check if pro license is active for semi-automatic mode
            if (is_aca_pro_active()) {
                $this->generate_ideas_semi_auto();
            } else {
                error_log('ACA: Semi-automatic mode requires Pro license');
            }
        }
    }
    
    /**
     * Auto-analyze style guide
     */
    private static function auto_analyze_style_guide() {
        // Skip auto-analysis in cron to avoid circular dependencies
        // This will be handled by the main plugin instance
        error_log('ACA: Style guide auto-analysis skipped in cron context');
    }
    
    /**
     * Generate ideas in semi-automatic mode
     */
    private static function generate_ideas_semi_auto() {
        // Skip idea generation in cron to avoid circular dependencies
        // This will be handled by the main plugin instance
        error_log('ACA: Semi-auto idea generation skipped in cron context');
        return;
    }
    
    /**
     * Run full automatic content cycle
     */
    private static function run_full_automatic_cycle() {
        // Skip full automatic cycle in cron to avoid circular dependencies
        // This will be handled by the main plugin instance
        error_log('ACA: Full automatic cycle skipped in cron context');
        return;
    }
    
    /**
     * Content freshness task
     */
    public static function content_freshness_task() {
        if (!is_aca_pro_active()) {
            return; // Pro feature only
        }
        
        $settings = get_option('aca_freshness_settings', array());
        $frequency = $settings['analysisFrequency'] ?? 'weekly';
        
        if (self::should_run_freshness_analysis($frequency)) {
            self::analyze_content_freshness();
        }
    }
    
    /**
     * Check if freshness analysis should run based on frequency
     */
    private static function should_run_freshness_analysis($frequency) {
        if ($frequency === 'manual') {
            return false;
        }
        
        $last_run = get_option('aca_last_freshness_analysis', 0);
        $current_time = time();
        
        // If this is the first run, set last_run to allow immediate execution
        if ($last_run == 0) {
            $last_run = $current_time - (7 * 24 * 60 * 60);
        }
        
        switch ($frequency) {
            case 'daily':
                return ($current_time - $last_run) > (24 * 60 * 60); // 24 hours
            case 'weekly':
                return ($current_time - $last_run) > (7 * 24 * 60 * 60); // 7 days
            case 'monthly':
                return ($current_time - $last_run) > (30 * 24 * 60 * 60); // 30 days
            default:
                return false;
        }
    }
    
    /**
     * Analyze content freshness
     */
    private static function analyze_content_freshness() {
        $freshness_manager = new ACA_Content_Freshness();
        
        // Get posts that need analysis using the approach from documentation
        $posts = get_posts(array(
            'post_status' => 'publish',
            'numberposts' => 10, // Limit to prevent timeout
            'meta_query' => array(
                array(
                    'key' => '_aca_last_freshness_check',
                    'value' => date('Y-m-d', strtotime('-7 days')),
                    'compare' => '<'
                )
            )
        ));
        
        $analyzed_count = 0;
        foreach ($posts as $post) {
            $analysis = $freshness_manager->analyze_post_freshness($post->ID);
            
            if (!is_wp_error($analysis)) {
                $analyzed_count++;
                
                if ($analysis['needs_update']) {
                    // Queue for manual review or auto-update based on settings
                    self::queue_content_update($post->ID, $analysis);
                }
                
                update_post_meta($post->ID, '_aca_last_freshness_check', current_time('mysql'));
            }
        }
        
        // Update last run time
        update_option('aca_last_freshness_analysis', time());
        
        // Log the activity
        if ($analyzed_count > 0) {
            self::add_activity_log('content_freshness_analysis', "Automatically analyzed $analyzed_count posts for content freshness", 'Sparkles');
        }
    }
    
    /**
     * Queue content update (from documentation)
     */
    private static function queue_content_update($post_id, $analysis) {
        // Get freshness settings
        $freshness_settings = get_option('aca_freshness_settings', array());
        
        // If auto-update is enabled, queue it
        if (isset($freshness_settings['autoUpdate']) && $freshness_settings['autoUpdate']) {
            require_once ACA_PLUGIN_PATH . 'includes/class-aca-content-freshness.php';
            $freshness_manager = new ACA_Content_Freshness();
            $freshness_manager->queue_content_update($post_id, $analysis);
        }
    }
    
    /**
     * Legacy method - kept for backward compatibility
     */
    private static function run_content_freshness_analysis() {
        // Check if Pro license is active (content freshness is a Pro feature)
        if (!is_aca_pro_active()) {
            return;
        }
        
        // Get freshness settings
        $freshness_settings = get_option('aca_freshness_settings', array());
        
        // Check if automatic analysis is enabled
        if (!isset($freshness_settings['enabled']) || !$freshness_settings['enabled']) {
            return;
        }
        
        // Check frequency
        $frequency = isset($freshness_settings['analysisFrequency']) ? $freshness_settings['analysisFrequency'] : 'weekly';
        if ($frequency === 'manual') {
            return;
        }
        
        // Check if it's time to run analysis based on frequency
        $last_run = get_option('aca_last_freshness_analysis', 0);
        $current_time = time();
        $should_run = false;
        
        // If this is the first run, set last_run to a week ago to allow immediate execution
        if ($last_run == 0) {
            $last_run = $current_time - (7 * 24 * 60 * 60);
        }
        
        switch ($frequency) {
            case 'daily':
                $should_run = ($current_time - $last_run) > (24 * 60 * 60); // 24 hours
                break;
            case 'weekly':
                $should_run = ($current_time - $last_run) > (7 * 24 * 60 * 60); // 7 days
                break;
            case 'monthly':
                $should_run = ($current_time - $last_run) > (30 * 24 * 60 * 60); // 30 days
                break;
        }
        
        if (!$should_run) {
            return;
        }
        
        // Load content freshness class
        require_once ACA_PLUGIN_PATH . 'includes/class-aca-content-freshness.php';
        $freshness_manager = new ACA_Content_Freshness();
        
        // Get posts that need analysis (limit to prevent timeout)
        $posts_to_analyze = $freshness_manager->get_posts_needing_analysis(5);
        
        $analyzed_count = 0;
        foreach ($posts_to_analyze as $post_id) {
            $analysis = $freshness_manager->analyze_post_freshness($post_id);
            
            if (!is_wp_error($analysis)) {
                $analyzed_count++;
                
                // Update meta field to track last analysis
                update_post_meta($post_id, '_aca_last_freshness_check', current_time('mysql'));
                
                // If post needs update and auto-update is enabled, queue it
                if ($analysis['needs_update'] && isset($freshness_settings['autoUpdate']) && $freshness_settings['autoUpdate']) {
                    $freshness_manager->queue_content_update($post_id, $analysis);
                }
            }
        }
        
        // Update last run time
        update_option('aca_last_freshness_analysis', $current_time);
        
        // Log the activity
        if ($analyzed_count > 0) {
            self::add_activity_log('content_freshness_analysis', "Automatically analyzed $analyzed_count posts for content freshness", 'Sparkles');
        }
    }
    
    /**
     * Add activity log entry
     */
    private static function add_activity_log($type, $details, $icon) {
        global $wpdb;
        
        $wpdb->insert(
            $wpdb->prefix . 'aca_activity_logs',
            array(
                'timestamp' => current_time('mysql'),
                'type' => $type,
                'details' => $details,
                'icon' => $icon
            )
        );
    }
}