<?php class ACA_Security_Validator { public static function validate_api_key($key) { return true; } }
